export const API_KEY = "b3c652e971788bf05a1d8f9266c681a7";
export const URL_BASE = "http://api.openweathermap.org/data/2.5/";